1) Upload self-lab-project.zip to the repository root.
2) In GitHub choose Add file > Create new file.
3) Filename: .github/workflows/build.yml
4) Paste the contents of build.yml from this bundle and commit it.
5) Open Actions > Build Self Lab APK > Run workflow.
6) Download the artifact self-lab-debug-apk.
