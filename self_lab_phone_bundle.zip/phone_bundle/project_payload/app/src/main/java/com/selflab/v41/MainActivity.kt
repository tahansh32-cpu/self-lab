package com.selflab.v41
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
private data class Msg(val role:String,val text:String)
class MainActivity:ComponentActivity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContent{App()}}}
@Composable fun App(){val ctx=LocalContext.current;val scope=rememberCoroutineScope();var key by remember{mutableStateOf("")};var input by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};var status by remember{mutableStateOf("جاهز")};var msgs by remember{mutableStateOf(listOf<Msg>())};val prefs=remember{EncryptedSharedPreferences.create("selflab",MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC),ctx,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)};LaunchedEffect(Unit){key=prefs.getString("api_key","")?:""};MaterialTheme{Column(Modifier.fillMaxSize().padding(12.dp)){Text("Self Lab 4.1",style=MaterialTheme.typography.headlineSmall);Text("Conversation Lab • $status");OutlinedTextField(key,{key=it;prefs.edit().putString("api_key",it).apply()},label={Text("DeepSeek API Key")},singleLine=true,modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(8.dp));LazyColumn(Modifier.weight(1f).fillMaxWidth()){items(msgs){m->Text("${if(m.role=="user")"أنت" else "Self Lab"}: ${m.text}",Modifier.padding(6.dp))}};Row(Modifier.fillMaxWidth()){OutlinedTextField(input,{input=it},label={Text("اكتب رسالتك")},modifier=Modifier.weight(1f));Spacer(Modifier.width(6.dp));Button(enabled=!busy&&input.isNotBlank()&&key.isNotBlank(),onClick{val text=input;input="";msgs=msgs+Msg("user",text);busy=true;status="يتصل…";scope.launch(Dispatchers.IO){val r=call(key,msgs);withContext(Dispatchers.Main){msgs=msgs+Msg("assistant",r);busy=false;status="متصل"}}}){Text("إرسال")}};Row{TextButton(onClick={msgs=listOf();status="تمت إعادة الذاكرة"}){Text("/reset")};TextButton(onClick={status="رسائل الذاكرة: ${msgs.size}"}){Text("/state")}}}}}
private fun call(key:String,msgs:List<Msg>):String{val a=JSONArray();a.put(JSONObject().put("role","system").put("content","You are the language engine inside Self Lab 4.1. Answer naturally and coherently. Do not claim consciousness. Answer in Arabic unless the user uses another language."));msgs.forEach{a.put(JSONObject().put("role",it.role).put("content",it.text))};val body=JSONObject().put("model","deepseek-chat").put("messages",a).put("stream",false).toString().toRequestBody("application/json".toMediaType());val req=Request.Builder().url("https://api.deepseek.com/chat/completions").addHeader("Authorization","Bearer $key").post(body).build();return try{OkHttpClient().newCall(req).execute().use{r->if(!r.isSuccessful)"خطأ API: HTTP ${r.code}" else JSONObject(r.body?.string()? : "{}").getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")}}catch(e:Exception){"تعذر الاتصال: ${e.message}"}}
